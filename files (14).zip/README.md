# Token Launch Forensics Bot 🔬

Real-time forensic analysis of every Pump.fun & Raydium token launch on Solana.  
Scores each launch on rug-risk, sends Telegram alerts, auto-snipes low-risk gems.

**43 files · 6000+ lines · 32 Python modules**

## Architecture

```
Scanners                    Fast Path              Queue              Pipeline
┌──────────────┐                                  ┌──────┐
│ Pump.fun WS  │──┐    ┌──────────────────┐       │Redis │     ┌─────────────────┐
├──────────────┤  ├───▶│ Deployer Alert    │──────▶│  or  │────▶│ 7 Analyzers     │
│ Raydium Logs │──┤    │ Network (<1ms)    │       │async │     │ (parallel)      │
├──────────────┤  │    └──────────────────┘       │Queue │     ├─────────────────┤
│ Migration WS │──┘           │                    └──────┘     │ · Deployer Hist │
└──────────────┘         ⚡ instant alert                       │ · Holders       │
                         if known scammer                       │ · LP Lock/Burn  │
                                                                │ · Bundled Buys  │
Output                          Scoring                         │ · Contract Pat  │
┌──────────────┐          ┌──────────────┐                     │ · Social        │
│ TG Alerts    │◀────────│ ML + Heurist │◀────────────────────│ · Wallet Clust  │
│ TG Channel   │          │ Blend Score  │                     └─────────────────┘
│ Sniper Signal│          └──────────────┘
│ Dashboard WS │                │
│ Prometheus   │          ┌─────┴──────┐
└──────────────┘          │ Outcome    │ ←── checks price at 1h/6h/24h
                          │ Tracker    │ ←── labels rug/survived
                          ├────────────┤
                          │ Post-Rug   │ ←── traces SOL flow after rugs
                          │ Fund Track │ ←── auto-watchlists new wallets
                          ├────────────┤
                          │ ML Auto    │ ←── retrains every 6h
                          │ Retrain    │ ←── 36 features, GBM classifier
                          └────────────┘
```

## Risk Score (0-100)

| Factor | Weight | Checks |
|--------|--------|--------|
| Deployer History | 20% | Wallet age, rug count, serial deploying |
| Holder Concentration | 20% | Top holder %, distribution |
| LP Status | 15% | Burned/locked/unlocked |
| Bundled Buys + Clusters | 15% | Coordinated buys, funding source analysis |
| Contract Patterns | 15% | Mint/freeze authority, copycat detection |
| Social Signals | 15% | Twitter/Telegram presence, bot score |

When ML model is trained (50+ labeled samples), scoring blends ML prediction with heuristics based on confidence level.

## Quick Start (Local Dev)

```bash
git clone https://github.com/AleisterMoltley/Token-Forensics.git
cd Token-Forensics

# Setup
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Configure
cp config/.env.example config/.env
# Edit config/.env → add HELIUS_API_KEY + TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID

# Run
python -m src.main
```

Dashboard: http://localhost:8080  
Health: http://localhost:8080/health  
Metrics: http://localhost:8080/metrics

## Deploy to Railway

```bash
# 1. Install Railway CLI
npm i -g @railway/cli && railway login

# 2. Create project
railway init

# 3. Add PostgreSQL (REQUIRED — SQLite data is lost on redeploy)
railway add postgresql

# 4. Add Redis (OPTIONAL — enables job queue with backpressure)
railway add redis

# 5. Set environment variables
railway variables set HELIUS_API_KEY=your_key
railway variables set TELEGRAM_BOT_TOKEN=your_token
railway variables set TELEGRAM_CHAT_ID=your_chat_id

# 6. Deploy
railway up

# 7. (Optional) Set custom domain
railway domain
```

Railway auto-detects `PORT`, `DATABASE_URL`, and `REDIS_URL` from addons.

## CI/CD (GitHub Actions)

Push to `main` → Lint → Test → Deploy to Railway automatically.

```bash
# Add Railway token to GitHub secrets
gh secret set RAILWAY_TOKEN

# Push triggers deploy
git push origin main
```

Scheduled ML retrain runs daily at 4 AM UTC via `.github/workflows/retrain.yml`.

## Telegram Commands

| Command | Description |
|---------|-------------|
| `/status` | Bot status & connection info |
| `/alerts on\|off` | Toggle alerts |
| `/threshold <0-100>` | Set min risk score for alerts |
| `/lookup <mint>` | Manual forensic scan |
| `/stats` | 24h statistics |
| `/watchlist add\|remove <addr>` | Manage deployer watchlist |
| `/export` | Export labeled training data CSV |
| `/migrations` | Recent Pump.fun→Raydium migrations |
| `/train` | Force retrain ML model |
| `/model` | ML model status & metrics |
| `/backtest` | Run backtest on historical data |
| `/help` | All commands |

## API Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /health` | Health check (Railway uses this) |
| `GET /metrics` | Prometheus metrics |
| `GET /api/stats` | 24h statistics |
| `GET /api/stats/hourly` | Hourly breakdown for charts |
| `GET /api/stats/score_distribution` | Score histogram data |
| `GET /api/launches?limit=50&min_score=0` | Recent launches |
| `GET /api/launches/{mint}` | Full detail for one token |
| `GET /api/deployers` | Top deployers by rug count |
| `GET /api/model` | ML model status |
| `GET /api/metrics` | JSON metrics + queue stats |
| `GET /api/backtest` | Run backtest, return results |
| `WS /ws` | Live token feed WebSocket |

## Project Structure

```
token-forensics/
├── src/
│   ├── main.py                 # Entry point, orchestrator
│   ├── config.py               # Settings + Railway auto-detection
│   ├── models.py               # SQLAlchemy models (SQLite/PostgreSQL)
│   ├── pipeline.py             # Forensic analysis pipeline
│   ├── scoring.py              # Risk scoring + ML blend
│   ├── ml_model.py             # ML predictor + auto-retrainer
│   ├── rpc.py                  # Solana RPC + Helius client
│   ├── dashboard.py            # FastAPI dashboard V2
│   ├── telegram_bot.py         # Telegram commands + alerts
│   ├── sniper_bridge.py        # Auto-sniper buy signals
│   ├── deployer_network.py     # Fast deployer alert network
│   ├── channel.py              # Public Telegram channel publisher
│   ├── queue.py                # Redis/asyncio job queue
│   ├── metrics.py              # Prometheus metrics exporter
│   ├── backtest.py             # Backtesting engine
│   ├── scanners/
│   │   ├── pump_fun.py         # Pump.fun WebSocket listener
│   │   ├── raydium.py          # Raydium new pool listener
│   │   └── migration.py        # Pump.fun→Raydium migration detector
│   └── analyzers/
│       ├── deployer.py         # Deployer wallet analysis
│       ├── holders.py          # Holder concentration analysis
│       ├── lp_check.py         # LP lock/burn checker
│       ├── bundled_buys.py     # Bundled buy detection
│       ├── contract_patterns.py # Rug pattern matching
│       ├── social.py           # Social sentiment scanner
│       ├── wallet_clusters.py  # Wallet cluster detection
│       ├── outcome_tracker.py  # 1h/6h/24h outcome labeling
│       └── post_rug_tracker.py # Post-rug fund tracer
├── tests/
│   └── test_forensics.py       # Test suite
├── .github/workflows/
│   ├── ci.yml                  # CI/CD pipeline
│   └── retrain.yml             # Scheduled ML retrain
├── config/
│   └── .env.example            # Environment template
├── Dockerfile                  # Railway-optimized container
├── railway.toml                # Railway deployment config
├── requirements.txt            # Python dependencies
└── pyproject.toml              # Ruff + pytest config
```

## Stack

- **Python 3.11+** with async/await throughout
- **Solana**: Helius RPC + DAS API, WebSocket subscriptions
- **Database**: PostgreSQL (Railway) / SQLite (local dev)
- **Queue**: Redis with asyncio fallback
- **ML**: scikit-learn GradientBoostingClassifier, 36 features
- **Dashboard**: FastAPI + Chart.js + WebSocket live feed
- **Alerts**: python-telegram-bot
- **CI/CD**: GitHub Actions → Railway
- **Monitoring**: Prometheus /metrics endpoint
